/* Runs on the audio rendering thread; only PCM windows leave the player. */
class MoshTap extends AudioWorkletProcessor {
 constructor(){super();this.buffer=new Float32Array(sampleRate*6);this.n=0;this.enabled=false;this.epoch=0;this.stride=this.buffer.length;this.nextUpdate=this.stride;this.port.onmessage=({data})=>{this.enabled=!!data.enabled;if(this.epoch!==data.epoch){this.epoch=data.epoch;this.n=0;this.anchor=data;}this.stride=data.foreground?sampleRate:this.buffer.length;this.nextUpdate=(Math.floor(this.n/this.stride)+1)*this.stride;};}
 emit(samples){const start=this.start,timeScale=this.anchor.timeScale||1;this.port.postMessage({samples,rate:sampleRate,epoch:this.epoch,start,end:start+samples.length/sampleRate*timeScale,timeScale},[samples.buffer]);}
 process(inputs){if(!this.enabled)return true;const input=inputs[0];if(input?.[0])for(let i=0;i<input[0].length;i++){if(!this.n)this.start=(this.anchor.mediaTime||0)+(currentFrame/sampleRate+i/sampleRate-(this.anchor.audioTime||0))*(this.anchor.timeScale||1);let s=0;for(const ch of input)s+=ch[i];this.buffer[this.n++]=s/input.length;
  // Foreground subtitles target one update per second, with the same growing
  // six-second recognition context. Background films keep the full-window rate.
  if(this.n===this.buffer.length){this.emit(this.buffer);this.buffer=new Float32Array(sampleRate*6);this.n=0;this.nextUpdate=this.stride;}
  else if(this.n>=this.nextUpdate){const samples=this.buffer.slice(0,this.n);this.emit(samples);this.nextUpdate+=this.stride;}
 }return true;}
}
registerProcessor('mosh-tap',MoshTap);
