/* Isolated extension world: worklet loading does not inherit YouTube's CSP. */
globalThis.MoshPlayerAudio=class {
 constructor(send){this.send=send;this.enabled=false;this.epoch=0;this.volume=0;this.pan=0;this.alive=true;}
 async audio(volume=this.volume,panning=this.pan,tau=.45,fadeId){
  const revision=this.audioRevision=(this.audioRevision||0)+1;
  this.volume=Number.isFinite(volume)?Math.max(0,Math.min(1,volume)):0;this.pan=Number.isFinite(panning)?Math.max(-1,Math.min(1,panning)):0;
  const v=document.querySelector('video');if(!v){this.send('audio-status',{state:'waiting-for-video',routed:false});return;}
  if(!this.context){this.video=v;this.context=new AudioContext({latencyHint:'playback'});this.source=this.context.createMediaElementSource(v);this.panner=this.context.createStereoPanner();this.gain=this.context.createGain();this.gain.gain.value=0;this.source.connect(this.panner).connect(this.gain).connect(this.context.destination);
   this.bindInput(v);
  }
  this.clearDelay();
  const ctx=this.context;this.send('audio-status',{state:ctx.state,rate:ctx.sampleRate,routed:ctx.state==='running'&&!v.muted&&v.volume===1});
  if(ctx.state!=='running')await ctx.resume();if(!this.alive||revision!==this.audioRevision)return;
  if(this.fadeMarker){this.fadeMarker.onended=null;this.fadeMarker.stop();this.fadeMarker.disconnect();this.fadeMarker=null;}
  v.muted=false;v.volume=1;const now=ctx.currentTime;this.gain.gain.cancelAndHoldAtTime(now);
  if(fadeId){
   const end=now+tau;this.gain.gain.linearRampToValueAtTime(this.volume,end);
   // A silent scheduled source reports completion on the audio clock, even if
   // wall timers are throttled or the context is suspended in the meantime.
   const marker=this.fadeMarker=ctx.createConstantSource();marker.offset.value=0;
   marker.onended=()=>{marker.disconnect();if(this.fadeMarker===marker)this.fadeMarker=null;if(this.alive&&revision===this.audioRevision)this.send('audio-faded',{fadeId});};marker.start(now);marker.stop(end);
  }else this.gain.gain.setTargetAtTime(this.volume,now,Math.max(.01,tau));
  this.panner.pan.setTargetAtTime(this.pan,now,.4);
  this.send('audio-status',{state:ctx.state,rate:ctx.sampleRate,routed:ctx.state==='running'&&!v.muted&&v.volume===1});
 }
 clearDelay(){
  if(!this.delayNode)return;
  this.delayNode.delayTime.cancelScheduledValues(this.context.currentTime);
  this.panner.disconnect();this.delayNode.disconnect();this.panner.connect(this.gain);
  this.delayNode=null;this.delayTarget=null;
 }
 // Compatibility with already-open clients: audio is always undelayed.
 async setDelay(_seconds,volume,_mediaTime=-1){
  await this.audio(volume,this.pan,.02);
  this.send('audio-delay-status',{seconds:0,actualSeconds:0,state:this.context?.state,routed:this.context?.state==='running',delayed:false});
 }
 bindInput(v){
   // YouTube can reapply its autoplay mute after our first audio command.
   // Once routed, the app's gain owns muting; the media input must stay open.
   this.keepInputOpen=()=>{if(!this.alive)return;if(v.muted)v.muted=false;if(v.volume!==1)v.volume=1;};
   this.mediaReset=event=>{this.keepInputOpen();if(event.type==='waiting'||event.type==='pause'||event.type==='seeking'||event.type==='ended')this.buffering=true;else if(event.type==='playing')this.buffering=false;this.reset();};
   v.addEventListener('volumechange',this.keepInputOpen);
   for(const event of ['seeking','pause','playing','waiting','ended','ratechange'])v.addEventListener(event,this.mediaReset);
  this.keepInputOpen();
 }
 config(){return {enabled:this.enabled&&!this.buffering&&!this.video.paused&&!this.video.seeking&&!this.video.ended&&this.video.readyState>=3,epoch:this.epoch,foreground:this.foreground,mediaTime:this.video.currentTime,audioTime:this.context.currentTime,timeScale:this.video.playbackRate};}
 reset(){this.epoch++;this.node?.port.postMessage(this.config());}
 async pcm(enabled,volume,panning,foreground=false){
  const changed=this.foreground!==foreground;this.foreground=foreground;
  const wasEnabled=this.enabled;this.enabled=!!enabled;if(!this.enabled){this.reset();return;}
  if(!this.context)await this.audio(volume,panning);else if(this.context.state!=='running')await this.context.resume();if(!this.alive)return;
  if(this.node&&!wasEnabled)this.reset();
  else if(this.node&&changed)this.node.port.postMessage(this.config());
  if(!this.loading)this.loading=(async()=>{
   await this.context.audioWorklet.addModule(chrome.runtime.getURL('audio-tap.js'));
   if(!this.alive)return;
   this.node=new AudioWorkletNode(this.context,'mosh-tap',{numberOfOutputs:0});this.source.connect(this.node);
   this.node.port.onmessage=({data})=>{if(this.enabled&&this.alive&&data.epoch===this.epoch)this.send('pcm',data,[data.samples.buffer]);};this.reset();
  })().catch(e=>{this.loading=null;throw e;});
  await this.loading;
 }
 dispose(){if(this.closing)return this.closing;this.alive=false;this.enabled=false;this.video?.removeEventListener('volumechange',this.keepInputOpen);for(const event of ['seeking','pause','playing','waiting','ended','ratechange'])this.video?.removeEventListener(event,this.mediaReset);if(this.fadeMarker){this.fadeMarker.onended=null;this.fadeMarker.stop();this.fadeMarker.disconnect();this.fadeMarker=null;}if(this.node){this.node.port.onmessage=null;this.node.port.close();this.node.disconnect();}this.source?.disconnect();this.delayNode?.disconnect();this.panner?.disconnect();this.gain?.disconnect();return this.closing=this.context?.close()||Promise.resolve();}
};
