// Every embedding app can connect, on any hostname or port. No origin allowlist.
// connect.js accepts handshakes only from the iframe's actual parent; player.js
// binds subsequent commands and frame delivery to that parent origin and token.
chrome.runtime.onMessage.addListener((request,sender,reply)=>{
 if(request.type!=='connect'||!sender.tab||!/^https:\/\/www\.youtube(?:-nocookie)?\.com\/embed\//.test(sender.url||'')||typeof request.origin!=='string')return;
 (async()=>{
  const target={tabId:sender.tab.id,frameIds:[sender.frameId]};
  await chrome.scripting.executeScript({target,world:'MAIN',func:(origin)=>{window.__moshAllowedParent=origin;},args:[request.origin]});
  await chrome.scripting.executeScript({target,world:'MAIN',files:['player.js']});return {ok:true};
 })().then(reply,e=>reply({error:e.message}));return true;
});
