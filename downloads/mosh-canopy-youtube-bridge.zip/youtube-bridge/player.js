(()=>{
 if(window.__moshPlayerBridge)return;window.__moshPlayerBridge=true;
 const origin=window.__moshAllowedParent;delete window.__moshAllowedParent;if(!origin)return;
 // Keep the provider's caption transport available without displaying a second
 // subtitle layer over Mosh Canopy's clickable words.
 const captionStyle=document.createElement('style');captionStyle.textContent='.ytp-caption-window-container{display:none!important}';(document.head||document.documentElement).append(captionStyle);
 let token=null,initialized=false,v,alive=true,busy=false,wantFrames=true,wantCaptions=false,frameId,sequence=0,lastMetadata='',lastFailure='',lastCaptions='',trackTries=0,captionPending=false,captionBlocked=false,captionTimer,captionAbort,nextCaptionAt=0;
 let captureClock='presentation',captureFps=30,captureTimer,lastCapture=0,lastMediaTime=-1,lastDecodedFrame=-1;
 const send=(type,data={},transfer=[])=>{if(token)parent.postMessage({type:'mosh-youtube',event:type,token,...data},origin,transfer);};
 const player=()=>document.querySelector('#movie_player');
 let pendingSeek=null,completedSeekId=null;
 function applySeek(){
  if(!pendingSeek||pendingSeek.applied||!v||v.readyState<1)return;
  pendingSeek.applied=true;
  // Wait for metadata, then seek the actual media element. The player API can
  // silently ignore a seek issued while its new embed is still initializing.
  v.currentTime=pendingSeek.time;
 }
 function mediaEvent(event){
  if(event.type==='loadedmetadata')applySeek();
  if(event.type==='seeked')completeSeek();
  state();frames();
 }
 function completeSeek(){
  if(pendingSeek?.applied&&!v.seeking&&v.readyState>=2){completedSeekId=pendingSeek.id;pendingSeek=null;}
 }
 function response(){try{return player()?.getPlayerResponse?.()}catch{return null}}
 function metadata(){const r=response(),details=r?.videoDetails,tracks=r?.captions?.playerCaptionsTracklistRenderer?.captionTracks||[];
  // Embed-denied films can have no getPlayerResponse() at all. Their native
  // player still exposes an explicit error in getVideoData(); do not mistake
  // that terminal state for a film which is merely buffering.
  const native=player()?.getVideoData?.(),nativeCode=native?.errorCode;
  const nativeFailed=native?.isPlayable===false&&nativeCode!=null&&nativeCode!==''&&nativeCode!==0&&nativeCode!=='0';
  const nativeReason=nativeFailed?player()?.querySelector?.('.ytp-error-content-wrap')?.innerText?.trim():'';
  const error=r?.playabilityStatus?.status!=='OK'&&r?.playabilityStatus ||
   (nativeFailed?{status:'NATIVE_ERROR',reason:nativeReason||String(nativeCode)}:null) ||
   (v?.error?{status:'MEDIA_ERROR',reason:v.error.message||'Media error '+v.error.code}:null);
  if(error){
   const signature=JSON.stringify(error);if(signature===lastFailure)return tracks;lastFailure=signature;
   const text=[];const collect=x=>{if(!x||typeof x!=='object')return;for(const [key,value]of Object.entries(x)){if((key==='text'||key==='content'||key==='simpleText')&&typeof value==='string')text.push(value);else if(value&&typeof value==='object')collect(value);}};collect(error.errorScreen);
   const detail=[...new Set(text)].join(' '),temporary=/try again later|temporarily unavailable/i.test([detail,error.reason].join(' '));
   if(temporary){captionBlocked=true;clearTimeout(captionTimer);captionAbort?.abort();send('caption-transport',{kind:'provider-unavailable',error:detail||error.reason});}
   if(error.status==='LOGIN_REQUIRED'||/not a bot|sign in|captcha/i.test(error.reason||'')){captionBlocked=true;clearTimeout(captionTimer);captionAbort?.abort();send('caption-transport',{kind:'auth-required',error:error.reason||error.status});}
   send('error',{error:error.reason||error.status,detail,status:error.status,temporary});
  }else {lastFailure='';
  if(details){const data={title:details.title,duration:+details.lengthSeconds,youtubeId:details.videoId,captionStatus:tracks.length||r?.playabilityStatus?.status!=='OK'?'loading':'unavailable',tracks:tracks.map(t=>({language:t.languageCode,kind:t.kind}))};const key=JSON.stringify(data);if(key!==lastMetadata){lastMetadata=key;send('metadata',data);}}
  }
  return tracks;
 }
 async function captions(raw,url){try{if(!raw?.events)return;const signature=JSON.stringify(raw);if(signature===lastCaptions)return;lastCaptions=signature;send('captions',{data:raw,language:new URL(url,location.href).searchParams.get('lang')||'und'});}catch{}}
 // Observe the player's successful timed-text requests, including tokens added by
 // YouTube itself. Cookies and signed request URLs never leave the YouTube frame.
 function transport(status,retryAfter,url){
  if(!/\/(?:api\/timedtext|youtubei\/v1\/player)(?:[?/#]|$)/.test(String(url)))return false;
  if(status!==429&&status!==401&&status!==403&&status<500)return false;
  const seconds=Number(retryAfter),retryAfterMs=retryAfter?Math.max(0,Number.isFinite(seconds)?seconds*1000:Date.parse(retryAfter)-Date.now()):0;
  const kind=status===429?'rate-limit':status===401?'auth-required':'transient';
  const scope=String(url).includes('/api/timedtext')?'captions':'playback';
  send('caption-transport',{kind,scope,status,retryAfterMs:Number.isFinite(retryAfterMs)?retryAfterMs:0,error:'YouTube '+scope+' HTTP '+status});
  if(kind!=='transient'||retryAfterMs>0){captionBlocked=true;clearTimeout(captionTimer);captionAbort?.abort();}
  return true;
 }
 const originalFetch=window.fetch;window.fetch=async function(...args){const r=await originalFetch.apply(this,args);const url=typeof args[0]==='string'?args[0]:args[0] instanceof URL?args[0].href:args[0]?.url;
  const failed=transport(r.status,r.headers.get('Retry-After'),url);
  if(!failed&&url?.includes('/api/timedtext'))r.clone().json().then(data=>captions(data,url)).catch(()=>{});return r;};
 const open=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(method,url,...args){if(/\/(?:api\/timedtext|youtubei\/v1\/player)(?:[?/#]|$)/.test(String(url)))this.addEventListener('load',()=>{
  if(transport(this.status,this.getResponseHeader('Retry-After'),url))return;
  if(String(url).includes('/api/timedtext'))try{captions(this.responseType==='json'?this.response:JSON.parse(this.responseText),String(url))}catch{}
 },{once:true});return open.call(this,method,url,...args);};
 async function pullCaptions(){
  if(!alive||!token||!wantCaptions||lastCaptions||captionPending||captionBlocked||trackTries>=3)return;
  if(Date.now()<nextCaptionAt){clearTimeout(captionTimer);captionTimer=setTimeout(pullCaptions,nextCaptionAt-Date.now());return;}
  const tracks=metadata();if(!tracks?.length)return;captionPending=true;
  const track=tracks.find(t=>t.languageCode==='en'&&t.kind!=='asr')||tracks.find(t=>t.languageCode==='en')||tracks[0];
  try{
   player()?.loadModule?.('captions');player()?.setOption?.('captions','track',{languageCode:track.languageCode});
   // Give the native request first refusal; never overlap fallback requests.
   await new Promise(resolve=>setTimeout(resolve,2000));
   if(!alive||!wantCaptions||lastCaptions||captionBlocked)return;
   trackTries++;
   const recent=performance.getEntriesByType('resource').filter(e=>e.name.includes('/api/timedtext')).at(-1)?.name;
   const url=new URL(recent||track.baseUrl);url.searchParams.set('fmt','json3');
   captionAbort=new AbortController();const deadline=setTimeout(()=>captionAbort?.abort(),15000);
   try{const r=await originalFetch(url,{credentials:'include',signal:captionAbort.signal});
    if(!transport(r.status,r.headers.get('Retry-After'),url)&&r.ok)await captions(await r.json(),url.href);
   }finally{clearTimeout(deadline);captionAbort=null;}
  }catch{}finally{
   captionPending=false;
   if(alive&&wantCaptions&&!lastCaptions&&!captionBlocked){
    if(trackTries>=3)send('caption-status',{status:'failed',error:'The player did not return a readable caption track'});
    else{nextCaptionAt=Date.now()+5000*2**trackTries+Math.random()*2000;clearTimeout(captionTimer);captionTimer=setTimeout(pullCaptions,nextCaptionAt-Date.now());}
   }
  }
 }
 function state(){if(!v)return;send('state',{time:v.currentTime,duration:v.duration||0,paused:v.paused,ended:v.ended,seeking:v.seeking,ready:v.readyState,width:v.videoWidth,height:v.videoHeight,rate:v.playbackRate});}
 async function deliverFrame(source,mediaTime){
  if(!alive||source!==v||!wantFrames||busy)return;
  completeSeek();busy=true;lastCapture=performance.now();const seekId=completedSeekId,decoded=source.getVideoPlaybackQuality?.().totalVideoFrames??source.currentTime;
  try{const frame=await createImageBitmap(source);
   if(!alive||source!==v||!wantFrames){frame.close();busy=false;if(alive)send('frame-idle');frames();return;}
   lastMediaTime=mediaTime;lastDecodedFrame=decoded;
   send('frame',{frame,time:mediaTime,seekId,sequence:++sequence,width:frame.width,height:frame.height},[frame]);
  }catch(e){busy=false;send('frame-idle');send('error',{error:'Frame transfer: '+e.message});frames();}
 }
 function frames(){
  if(!alive||!v||!token||!wantFrames||busy||frameId!==undefined||captureTimer!==undefined)return;
  const source=v;
  if(captureClock==='consumer')return;
  if(captureClock==='media'){
   // A hidden embed can decode at full speed while Chromium throttles its
   // presentation callbacks to 1 Hz. TD consumes decoded pixels independently
   // of whether the iframe is displayed. Still keep one bitmap outstanding.
   captureTimer=setTimeout(()=>{
    captureTimer=undefined;if(!alive||source!==v||!wantFrames)return;
    const mediaTime=source.currentTime;
    if(source.readyState<2||source.seeking||Math.abs(mediaTime-lastMediaTime)<.0001){lastCapture=performance.now();frames();return;}
    void deliverFrame(source,mediaTime);
   },Math.max(0,1000/captureFps-(performance.now()-lastCapture)));
  }else{
   frameId=source.requestVideoFrameCallback((_now,info)=>{frameId=undefined;void deliverFrame(source,info.mediaTime);});
  }
 }
 function cancelFrame(){if(frameId!==undefined){v?.cancelVideoFrameCallback(frameId);frameId=undefined;}clearTimeout(captureTimer);captureTimer=undefined;}
 function setCaptureClock(mode,fps){
  cancelFrame();captureClock=mode==='consumer'?'consumer':mode==='media'?'media':'presentation';captureFps=Math.max(1,Math.min(60,Number(fps)||30));frames();
 }
 addEventListener('message',async e=>{if(e.source!==parent||e.origin!==origin||e.data?.type!=='mosh-youtube-command')return;
  const d=e.data;if(token&&d.token!==token)return;token=d.token;
  try{switch(d.command){
   case 'init': wantFrames=d.frames!==false;if(d.captureClock)setCaptureClock(d.captureClock,d.captureFps);if(!initialized){wantCaptions=d.captions!==false;initialized=true;}send('connected',{frameCredit:true,seekAcknowledgement:true,disposeAcknowledgement:true,captionDemand:true,independentCaptureClock:true,consumerCaptureClock:true});metadata();state();frames();void pullCaptions();break;
   case 'ack': busy=false;frames();break;
   case 'capture-clock':setCaptureClock(d.mode,d.fps);break;
   case 'sample-frame':{
    // The visible app asks for decoded frames. Hidden iframe presentation
    // callbacks can run at 1 Hz even while its media decoder advances normally.
    // One bitmap credit remains in force, and unchanged decoded frames cost no copy.
    if(captureClock!=='consumer'||busy)break;
    const decoded=v?.getVideoPlaybackQuality?.().totalVideoFrames??v?.currentTime;
    if(!v||!alive||!wantFrames||v.readyState<2||v.seeking||decoded===lastDecodedFrame&&!pendingSeek){send('frame-idle');break;}
    void deliverFrame(v,v.currentTime);break;
   }
   case 'play':player()?.playVideo?.();break;
   case 'pause':player()?.pauseVideo?.();break;
   case 'seek':completedSeekId=null;pendingSeek={id:d.seekId,time:Math.max(0,d.time),applied:false};cancelFrame();applySeek();frames();break;
   case 'captions':wantCaptions=d.enabled!==false;if(wantCaptions)void pullCaptions();else{clearTimeout(captionTimer);captionAbort?.abort();player()?.unloadModule?.('captions');}break;
   case 'frames':wantFrames=d.enabled;if(wantFrames)frames();else cancelFrame();break;
   case 'dispose':alive=false;clearInterval(timer);clearTimeout(captionTimer);captionAbort?.abort();cancelFrame();v?.pause?.();send('disposed',{component:'player'});break;
  }}catch(error){send('warning',{error:error.message});}
 });
 const timer=setInterval(()=>{if(!alive){clearInterval(timer);return;}const found=document.querySelector('video');if(found&&found!==v){cancelFrame();v=found;lastDecodedFrame=-1;for(const event of ['loadedmetadata','seeked','playing','pause','ended'])v.addEventListener(event,mediaEvent);applySeek();frames();}if(token){state();metadata();}},400);
 setTimeout(()=>void pullCaptions(),3000);setTimeout(()=>void pullCaptions(),9000);
})();
