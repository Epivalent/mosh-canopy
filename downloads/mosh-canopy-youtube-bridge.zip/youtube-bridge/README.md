# Mosh Canopy YouTube bridge

The app uses native YouTube players in your browser. This extension passes their decoded frames, captions and audio samples to the page embedding the YouTube player. YouTube cookies and signed media URLs remain inside the player. No YouTube media relay is used.

## Install in Brave or Chrome

1. In Mosh Canopy, open **Guide → YouTube bridge** and download the ZIP. Unzip it into a folder you will keep.
2. Open `brave://extensions` (or `chrome://extensions`) in the address bar and enable **Developer mode**.
3. Choose **Load unpacked** and select the extracted `youtube-bridge` directory containing `manifest.json`, not the ZIP or its parent folder.
4. Return to the app and reload it. The bridge connects automatically; no site approval or toolbar click is required.
5. Click **Hear films** to enable sound and audio capture for live Voz transcription.

For updates, click the extension's **Reload** button on the extensions page, then reload Mosh Canopy.

Version 0.1.12 connects automatically from every app origin: LAN IPs, local or public hostnames, HTTP or HTTPS, and any port. There is no app-origin allowlist or per-site approval. Commands and frames remain bound to the actual embedding parent and its connection token.

To update a downloaded installation, extract the new ZIP over the existing extension folder, click **Reload** on `brave://extensions`, then reload the app. Downloading the ZIP alone does not update an installed unpacked extension.

## What works

- Native YouTube playback, live bead textures, large frame, seeking and spatial sound.
- YouTube captions, clickable CCs, word helices and concordance.
- Live Voz fallback from a 16 kHz audio worklet when native captions are absent.
- Existing GPU object segmentation and collage cutouts from transferred frames; no additional media download or video decoder.

The audio worklet is packaged in the extension and runs in its isolated context. A browser audio gesture is required after loading the page. Videos unavailable to the native YouTube player remain unavailable here.

Caption collection runs in a standalone Node job. Published transcripts are shared files served with the app; newly captured browser captions are also retained in IndexedDB.

## Playback without the extension

Native YouTube playback, seeking, volume and published clickable captions work without this extension. The viewing player stays attached to the film rectangle; beads show collected animated previews, falling back to their own film thumbnail where no preview exists. The extension adds full decoded film textures, frame extraction and audio capture for live transcription. Loading or enabling it upgrades the existing player without opening a second film stream.

Version 0.1.7 lets the app check its transcript collection before requesting captions again. A complete published or locally collected transcript needs no new caption download.

Version 0.1.8 sends provisional foreground speech windows once per second, growing to the existing six-second context. Background audio retains the six-second cadence. Update the extension and reload the app to use this faster live-caption path. The app also replays audio-capture requests made before the bridge or media element was ready.

## If a plain embed works but the beads do not

Check that this extension is installed **in the browser profile displaying Mosh Canopy**. Installing it in a separate test profile does not enable it in your normal profile. In a private window, also enable **Allow in Incognito** on the extension's Details page.

Version 0.1.6 repeats handshake acknowledgements when the app asks again. The app now reports a missing bridge instead of leaving the background startup queue waiting indefinitely. This does not clear cookies or classify missing frame transfer as a failed YouTube film.

Version 0.1.11 adds an opt-in decoded-video capture clock for the TouchDesigner bridge. It keeps sending frames when an invisible YouTube iframe has its presentation callbacks throttled. Normal Mosh Canopy frame capture remains presentation-driven.
