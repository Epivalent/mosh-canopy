let busy=false,connected=false,origin,token,audio;
addEventListener('message',async e=>{
 if(e.source!==parent)return;const d=e.data;
 // Handshake acknowledgement is repeatable. A lost/early reply must not leave
 // the parent waiting forever while this document believes it is connected.
 if(d?.type==='mosh-youtube-connect'&&connected&&e.origin===origin){parent.postMessage({type:'mosh-youtube-extension-ready',audioFades:true,disposeAcknowledgement:true},origin);return;}
 if(d?.type==='mosh-youtube-connect'&&!connected&&!busy){
  busy=true;try{const result=await chrome.runtime.sendMessage({type:'connect',origin:e.origin});if(result?.ok){connected=true;origin=e.origin;parent.postMessage({type:'mosh-youtube-extension-ready',audioFades:true,disposeAcknowledgement:true},origin);}else parent.postMessage({type:'mosh-youtube-bridge-error',error:result?.error||'Extension unavailable'},e.origin);}catch(error){parent.postMessage({type:'mosh-youtube-bridge-error',error:error.message},e.origin);}finally{busy=false;}return;
 }
 if(!connected||e.origin!==origin||d?.type!=='mosh-youtube-command'||(token&&d.token!==token))return;
 if(!token&&d.command!=='init')return;token=d.token;
 const send=(event,data={},transfer=[])=>parent.postMessage({type:'mosh-youtube',event,token,...data},origin,transfer);
 try{if(d.command==='audio'){audio??=new MoshPlayerAudio(send);await audio.audio(d.volume,d.pan,d.tau,d.fadeId);}
  else if(d.command==='audio-delay'){audio??=new MoshPlayerAudio(send);await audio.setDelay(d.seconds,d.volume,d.mediaTime);}
  else if(d.command==='pcm'){audio??=new MoshPlayerAudio(send);await audio.pcm(d.enabled,d.volume,d.pan,d.foreground);}
  else if(d.command==='dispose'){await audio?.dispose();send('disposed',{component:'audio'});}
 }catch(error){send('warning',{error:error.message,component:'audio'});}
});
